<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "wideprotection"; // Replace with your MySQL username
$password = "Lovemore3#"; // Replace with your MySQL password
$dbname = "comments_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, avatar, comment, created_at FROM comments ORDER BY created_at DESC";
$result = $conn->query($sql);

$comments = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }
}

$conn->close();

echo json_encode($comments);


