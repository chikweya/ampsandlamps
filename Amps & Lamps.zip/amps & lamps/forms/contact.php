<?php
// Load the "PHP Email Form" library
require '../vendor/php-email-form/php-email-form.php';

// Replace with your real receiving email address
$receiving_email_address = 'iyetererai@gmail.com';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contact = new PHP_Email_Form;
    $contact->ajax = true;
    
    $contact->to = $receiving_email_address;
    $contact->from_name = $_POST['name'];
    $contact->from_email = $_POST['email'];
    $contact->subject = $_POST['subject'];

    // SMTP configuration
    $contact->smtp = array(
        'host' => 'smtp.gmail.com',
        'username' => 'iyetererai@gmail.com',
        'password' => 'lovemore3',
        'port' => '465',  // or 465 for SSL
        'encryption' => 'ssl'  // or 'ssl' if using port 465
    );

    // Add the form messages
    $contact->add_message($_POST['name'], 'Name');
    $contact->add_message($_POST['email'], 'Email');
    $contact->add_message($_POST['subject'], 'Subject');
    $contact->add_message($_POST['message'], 'Message', 10);

    // Send the email and handle the response
    if ($contact->send()) {
        echo 'Your message has been sent. Thank you!';
    } else {
        echo 'Message could not be sent. Please try again later.';
    }
} else {
    echo 'Invalid request method.';
}

