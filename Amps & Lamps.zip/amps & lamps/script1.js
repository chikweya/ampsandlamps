document.addEventListener('DOMContentLoaded', function() {
    fetchComments();
});

function fetchComments() {
    fetch('fetch_comments.php')
        .then(response => response.json())
        .then(data => {
            const commentsContainer = document.getElementById('comments-container');
            commentsContainer.innerHTML = '';
            data.forEach(comment => {
                const commentContainer = document.createElement('div');
                commentContainer.className = 'comment';

                const avatar = document.createElement('img');
                avatar.className = 'avatar';
                avatar.src = comment.avatar;

                const commentContent = document.createElement('div');
                commentContent.className = 'comment-content';

                const name = document.createElement('h4');
                name.textContent = comment.name;

                const commentText = document.createElement('p');
                commentText.textContent = comment.comment;

                commentContent.appendChild(name);
                commentContent.appendChild(commentText);

                commentContainer.appendChild(avatar);
                commentContainer.appendChild(commentContent);

                commentsContainer.appendChild(commentContainer);
            });
        })
        .catch(error => console.error('Error fetching comments:', error));
}
