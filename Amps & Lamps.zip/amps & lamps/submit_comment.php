<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $service = $_POST['service'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    // Read existing testimonials
    $testimonials = json_decode(file_get_contents('testimonials.json'), true);

    // Add new testimonial
    $testimonials[] = [
        'name' => $name,
        'service' => $service,
        'rating' => $rating,
        'comment' => $comment,
        'avatar' => 'assets/img/testimonials/testimonials-' . rand(1, 4) . '.jpg' // Random avatar
    ];

    // Save testimonials
    file_put_contents('testimonials.json', json_encode($testimonials));

    // Redirect back to the form page or show success message
    header('Location: thank_you.html');
    exit;
}
?>

